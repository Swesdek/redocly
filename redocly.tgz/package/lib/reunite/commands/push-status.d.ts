import type { OutputFormat } from '@redocly/openapi-core';
import type { VerifyConfigOptions } from '../../types.js';
import type { CommandArgs } from '../../wrapper.js';
import type { DeploymentStatusResponse, PushResponse } from '../api/types.js';
export type PushStatusArgv = {
    organization: string;
    project: string;
    pushId: string;
    domain?: string;
    format?: Extract<OutputFormat, 'stylish'>;
    wait?: boolean;
    'max-execution-time'?: number;
    'retry-interval'?: number;
    'start-time'?: number;
    'continue-on-deploy-failures'?: boolean;
    onRetry?: (lasSummary: PushStatusSummary) => void;
} & VerifyConfigOptions;
export interface PushStatusSummary {
    preview: DeploymentStatusResponse;
    production: DeploymentStatusResponse | null;
    commit: PushResponse['commit'];
}
export declare function handlePushStatus({ argv, }: CommandArgs<PushStatusArgv>): Promise<PushStatusSummary | void>;
//# sourceMappingURL=push-status.d.ts.map