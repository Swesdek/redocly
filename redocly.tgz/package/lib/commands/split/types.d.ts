import type { Oas2Definition, Oas3Definition, Oas3_1Definition, Oas3_2Definition } from '@redocly/openapi-core';
export type Definition = Oas2Definition | Oas3Definition | Oas3_1Definition | Oas3_2Definition;
export interface ComponentsFiles {
    [schemas: string]: any;
}
export interface RefObject {
    [$ref: string]: string;
}
export declare const COMPONENTS = "components";
export declare const PATHS = "paths";
export declare const WEBHOOKS = "webhooks";
export declare const xWEBHOOKS = "x-webhooks";
export type Oas3Method = (typeof OPENAPI3_METHOD_NAMES)[number];
export declare const OPENAPI3_METHOD_NAMES: readonly ["get", "put", "post", "delete", "options", "head", "patch", "trace", "query"];
export type Oas3Component = (typeof OPENAPI3_COMPONENT_NAMES)[number];
export declare const OPENAPI3_COMPONENT_NAMES: readonly ["schemas", "responses", "parameters", "examples", "headers", "requestBodies", "links", "callbacks", "securitySchemes"];
//# sourceMappingURL=types.d.ts.map