import type { Oas3PathItem, Referenced } from '@redocly/openapi-core';
import type { VerifyConfigOptions } from '../../types.js';
import type { CommandArgs } from '../../wrapper.js';
export type SplitArgv = {
    api: string;
    outDir: string;
    separator: string;
} & VerifyConfigOptions;
export declare function handleSplit({ argv, collectSpecData }: CommandArgs<SplitArgv>): Promise<void>;
export declare function startsWithComponents(node: string): boolean;
export declare function crawl(object: unknown, visitor: (node: Record<string, unknown>) => void): void;
declare function iteratePathItems(pathItems: Record<string, Referenced<Oas3PathItem>> | undefined, openapiDir: string, outDir: string, componentsFiles: object, pathSeparator: string, codeSamplesPathPrefix: string | undefined, ext: string): void;
export { iteratePathItems };
//# sourceMappingURL=index.d.ts.map