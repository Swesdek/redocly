import { type RuleSeverity } from '@redocly/openapi-core';
import { type OutputExtension, type VerifyConfigOptions } from '../types.js';
import { type CommandArgs } from '../wrapper.js';
export type BundleArgv = {
    apis?: string[];
    extends?: string[];
    output?: string;
    ext?: OutputExtension;
    dereferenced?: boolean;
    force?: boolean;
    metafile?: string;
    'remove-unused-components'?: boolean;
    'keep-url-references'?: boolean;
    'component-renaming-conflicts-severity'?: RuleSeverity;
    'skip-decorator'?: string[];
    'skip-preprocessor'?: string[];
} & VerifyConfigOptions;
export declare function handleBundle({ argv, config, version, collectSpecData, }: CommandArgs<BundleArgv>): Promise<void>;
//# sourceMappingURL=bundle.d.ts.map