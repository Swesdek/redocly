import type { Plugin } from '@redocly/openapi-core';
export declare function evaluatePluginsFromCode(pluginsCode?: string, verbose?: boolean): Promise<Plugin[]>;
//# sourceMappingURL=plugin-evaluator.d.ts.map