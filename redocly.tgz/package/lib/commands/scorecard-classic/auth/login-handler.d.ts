import type { Config } from '@redocly/openapi-core';
export declare function handleLoginAndFetchToken(config: Config, verbose?: boolean): Promise<string | null>;
//# sourceMappingURL=login-handler.d.ts.map