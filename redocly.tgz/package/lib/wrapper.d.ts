import type { Config, CollectFn } from '@redocly/openapi-core';
import type { Arguments } from 'yargs';
import type { CommandArgv } from './types.js';
export type CommandArgs<T extends CommandArgv> = {
    argv: T;
    config: Config;
    version: string;
    collectSpecData?: CollectFn;
};
export declare function commandWrapper<T extends CommandArgv>(commandHandler?: (wrapperArgs: CommandArgs<T>) => Promise<unknown>): (argv: Arguments<T>) => Promise<void>;
//# sourceMappingURL=wrapper.d.ts.map