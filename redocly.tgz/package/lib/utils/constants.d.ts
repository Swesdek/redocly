export declare const OTEL_URL = "https://otel.cloud.redocly.com";
export declare const OTEL_TRACES_URL: string;
export declare const DEFAULT_FETCH_TIMEOUT = 3000;
export declare const ANONYMOUS_ID_CACHE_FILE = "redocly-cli-anonymous-id";
//# sourceMappingURL=constants.d.ts.map