import type { ArazzoDefinition, Config } from '@redocly/openapi-core';
import type { Arguments } from 'yargs';
import type { CommandArgv } from '../types.js';
import type { ExitCode } from './miscellaneous.js';
export declare function sendTelemetry({ config, argv, exit_code, execution_time, spec_version, spec_keyword, spec_full_version, respect_x_security_auth_types, }: {
    config: Config | undefined;
    argv: Arguments<CommandArgv> | undefined;
    exit_code: ExitCode;
    execution_time: number;
    spec_version: string | undefined;
    spec_keyword: string | undefined;
    spec_full_version: string | undefined;
    respect_x_security_auth_types: string[] | undefined;
}): Promise<void>;
export declare function collectXSecurityAuthTypes(document: Partial<ArazzoDefinition>, respectXSecurityAuthTypesAndSchemeName: string[]): void;
export declare function cleanArgs(parsedArgs: CommandArgv, rawArgv: string[]): {
    arguments: string;
    raw_input: string;
};
export declare const cacheAnonymousId: (anonymousId: string) => void;
export declare const getCachedAnonymousId: () => string | undefined;
//# sourceMappingURL=telemetry.d.ts.map